Birthday Regsitry Skill for Amazon Echo
 
 Actions supported
  
  Register: Saves the name and the birtdhay of the individual into Dynamo database  
  Save: Same as "register" action.
  
